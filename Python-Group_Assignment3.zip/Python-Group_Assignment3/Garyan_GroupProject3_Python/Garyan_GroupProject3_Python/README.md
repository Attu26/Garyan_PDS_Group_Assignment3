Refer Problem Statement Graded Project3.pdf for problem statement.

Refer loan_approval_data.csv for dataset
